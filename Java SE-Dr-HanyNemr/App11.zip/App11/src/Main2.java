public class Main2 {
    public static void main(String[] args) {

        Playable p=new Playable() {
            @Override
            public void play(String sport) {
                System.out.println("playing "+sport);
            }
        };

        Playable p2=(sport)-> System.out.println("playing "+sport);

        test(sport-> System.out.println("playing "+sport));
    }

    public static void test(Playable p){
        p.play("sport");
    }
}
