import java.util.Objects;

public class Country {
    private String name,city;

    public Country(String name, String city) {
        this.name = name;
        this.city = city;
    }

    public Country() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @Override
    public String toString() {
        return "Country{" +
                "name='" + name + '\'' +
                ", city='" + city + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Country country = (Country) o;
        return name.equalsIgnoreCase(country.name) && city.equalsIgnoreCase(country.city);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, city);
    }

}
