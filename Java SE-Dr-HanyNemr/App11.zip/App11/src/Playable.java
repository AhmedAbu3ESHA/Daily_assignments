public interface Playable {
    void play(String sport);
}
