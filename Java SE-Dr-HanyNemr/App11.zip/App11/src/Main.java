import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        ArrayList<Country> countries=new ArrayList<>(List.of(
                new Country("usa","ws"),
                new Country("egypt","cairo"),
                new Country("france","paris")
                ));


//        Collections.sort(countries, (o1, o2) -> o1.getName().compareToIgnoreCase(o2.getName()));
        Collections.sort(countries,(o1, o2)-> o1.getName().compareToIgnoreCase(o2.getName()));
        System.out.println(countries);

//        Collections.shuffle(countries);

//        Country c1= new Country("egypt","Cairo");
//        Country c2= new Country("egypt","cairo");

//        if(c1.equals(c2)) System.out.println("true");
//        else System.out.println("false");

//        if (countries.contains(new Country("egypt","cairo"))) {
//            System.out.println("found");
//        }else System.out.println("not found");

        System.out.println(countries);
//        ArrayList<String> countries= new ArrayList<>(List.of("egypt","france","usa"));
//        ArrayList<String> cities=  new ArrayList<>(List.of("cairo","paris","ws"));
//
//        Collections.shuffle(countries);
//        System.out.println(countries);
//        System.out.println(cities);
    }
}