import java.util.*;
import java.util.function.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main4 {
    public static void main(String[] args) {
        List<String> names = List.of("ahmed", "hassan", "tamer", "ali", "hassan", "hassan", "ali");
        HashSet<String> nameSet=new HashSet<>(names);

//        Map<String, Integer> collect = names
//                .stream()
//                .collect(Collectors.toMap(name -> name, name-> name.length()));

        Map<String, Integer> map = nameSet.stream()
                .collect(Collectors
                        .groupingBy(name -> name, Collectors.summingInt(name -> Collections.frequency(names, name))));
        System.out.println(map);

        map.entrySet()
                .stream()
                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
                .forEach(entry-> System.out.println(entry.getKey()+" "+entry.getValue()));


//        Map<Boolean, List<String>> map = names.stream().collect(Collectors.partitioningBy(name -> name.length() > 3));

//        HashMap<String,Integer> map=new HashMap<>();
//        for (String name : names) {
//            map.put(name,name.length());
//        }

    }
}
