import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class Main3 {
    public static void main(String[] args) {
        Consumer<String> consumer=new Consumer<String>() {
            @Override
            public void accept(String s) {
                System.out.println(s);
            }
        };

       Consumer<String> con=s -> System.out.println(s);


        Supplier<String> sup=new Supplier<String>() {
            @Override
            public String get() {
                return "hello";
            }
        };

        Supplier<String> sup1=() -> "hello";

        Function<String,Integer> fun=new Function<String, Integer>() {
            @Override
            public Integer apply(String s) {
                return s.length();
            }
        };

        Function<String,Integer> funn=s -> s.length();

        Predicate<String> pr=new Predicate<String>() {
            @Override
            public boolean test(String s) {
                return s.length()>5;
            }
        };

        Predicate<String> pre=s-> s.length()>5;




    }
}
