import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Main3 {
    public static void main(String[] args) {

        //intstreams
        IntStream
                .range(0, 10)
                .boxed()
                .collect(Collectors.toList());

        System.out.println("------------------------");

        // from list to linkedmap
        List<String> names = List.of("ahmed", "tamer", "ali", "hossam", "hossam", "hany", "hany");

        LinkedHashMap<String, Long> collect = names.stream()
                .collect(Collectors.groupingBy(name -> name, Collectors.counting()))
                .entrySet().stream()
                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (a1, a2) -> a1, LinkedHashMap::new));

        System.out.println(collect);

        System.out.println("------------------------");
        //flatmap
        List<List<String>> data=List.of(List.of("ahmed","hany"),List.of("nada","heba"));
        data.stream()
                .map(elements->elements.stream())
                .forEach(element-> System.out.println(element));


    }
}
