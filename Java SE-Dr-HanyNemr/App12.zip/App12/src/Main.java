import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Main {

    public static void main(String[] args) {
        List<String> names = List.of("ahmed", "tamer", "ali", "hossam", "hossam", "hany", "hany");

        Map<String, Long> collect = names.stream().collect(Collectors.groupingBy(name -> name, Collectors.counting()));
        System.out.println(collect);
        LinkedHashMap<String, Long> map = collect.entrySet().stream()
                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (k1, k2) -> k1, LinkedHashMap::new));

        System.out.println(map);

        names.forEach(System.out::println);


//        List<List<String>> data= List.of(
//                List.of("ahmed","tamer","ali","hossam","hany"),
//                List.of("wael","mahmoud"),
//                List.of("nada","heba")
//        );
//        List<String> collect = data.stream().flatMap(list -> list.stream())
//                .filter(name -> !name.contains("m"))
//                .collect(Collectors.toList());
//        System.out.println(collect);









    }
}