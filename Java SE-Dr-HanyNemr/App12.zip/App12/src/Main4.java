import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

public class Main4 {
    public static void main(String[] args) {

        //paths-files
        Path path = Paths.get("data.txt");
        try {
            List<String> lines = Files.readAllLines(path);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        //using stream
        try {
            List<String> collect = Files
                    .lines(path)
                    .filter(line -> line.length() > 5)
                    .skip(2)
                    .limit(10)
                    .collect(Collectors.toList());
            System.out.println(collect);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
