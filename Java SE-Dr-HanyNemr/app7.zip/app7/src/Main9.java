import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main9 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        List<String> egypt = List.of("cairo", "alex", "aswan", "banha", "tanta");
        ArrayList<String> user=new ArrayList<>();
        ArrayList<Byte> scoreList=new ArrayList<>();
        for (int k = 0; k < 2; k++) {
            byte score=0;
            System.out.println("player "+(k+1));
            System.out.println("enter three cities in egypt");
            for (int i = 0; i < 3; i++) {
                String answer =s.next();
                if(!user.contains(answer) && egypt.contains(answer)) {
                    score++;
                    user.add(answer);
                }
            }
            System.out.println("score="+score);
            scoreList.add(score);
            user.clear();
        }
        //winner
        byte max= Collections.max(scoreList);
        int f=Collections.frequency(scoreList,max);
        if (f>1) System.out.println("tie");
        else{
            int index=scoreList.indexOf(max);
            System.out.println("winner is player "+(index+1));
        }

    }
}
