import java.util.Scanner;

public class Main11 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        String input="";
        while (true){
            input=s.next();
            if(input.equals("exit")) break;
            System.out.println(input);
        }
    }
}
