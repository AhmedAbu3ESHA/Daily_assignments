import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Main8 {
    public static void main(String[] args) {
        String statement="i love android i love java";
        //solution1
//        String[] array=statement.split(" ");
//        List<String> list= Arrays.asList(array);
//        ArrayList<String> container=new ArrayList<>();
//        for (String s : list) {
//            if(container.contains(s)) continue;
//            int f=Collections.frequency(list,s);
//            System.out.println(s+" "+f);
//            container.add(s);
//        }

        //solution2
//        String[] array=statement.split(" ");
//        List<String> list= Arrays.asList(array);
//        for (int i = 0; i < list.size(); i++) {
//            int index=list.indexOf(list.get(i));//0,1,2,0
//            if (index==i){
//                int f=Collections.frequency(list,list.get(i));
//                System.out.println(list.get(i)+" "+f);
//            }
//        }

        //solution3
//        String[] array=statement.split(" ");
//        List<String> list= Arrays.asList(array);
//        for (String s : list) {
//            if(s.isEmpty()) continue;
//            int f=Collections.frequency(list,s);
//            System.out.println(s+" "+f);
//            Collections.replaceAll(list,s,"");
//        }

        //solution4
        String[] array=statement.split(" ");
        List<String> list= Arrays.asList(array);
        for (int i = 0; i < list.size(); i++) {
            if(list.subList(0,i).contains(list.get(i))) continue;
            int f = Collections.frequency(list, list.get(i));
            System.out.println(list.get(i) + " " + f);
        }


    }
}
