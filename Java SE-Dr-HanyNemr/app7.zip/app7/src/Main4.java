import java.util.ArrayList;
import java.util.List;

public class Main4 {
    public static void main(String[] args) {
//        String[] data = {"ahmed", "hany", "wael", "tamer"};
//        for (int i = 0; i < data.length; i++) {
//            if(data[i].equals("wael")) {
//                System.out.println("found");
//                break;
//            } else if (i == data.length - 1) {
//                System.out.println("not found");
//            }
//        }

        ArrayList<String> data=new ArrayList<>();
        data.add("ahmed");
        data.add("hany");
        data.add("wael");
        data.add("tamer");

        if (data.contains("wael")) {
            int index=data.indexOf("wael");
            System.out.println("found in "+index);
        }
        else
            System.out.println("not found");

        ArrayList<String> copy=new ArrayList<>();
        copy.add("monika");
        copy.add("mariam");
        copy.add("mike");

        data.addAll(0,copy);
//        data.removeAll(copy);

//        data.clear();

        List<String> subList = data.subList(1, 5);
        System.out.println(data);

    }
}
