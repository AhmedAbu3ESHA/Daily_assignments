import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main7 {
    public static void main(String[] args) {
        ArrayList<String> data=new ArrayList<>();
        ArrayList<Integer> numbers=new ArrayList<>();
        Collections.addAll(numbers,20,25,15,22);
        Collections.addAll(data, "ahmed", "tamer", "wael","ahmed");
        Collections.fill(data,"");
        System.out.println(Collections.frequency(data, "ahmed"));
        int a=Collections.max(numbers);
        List<Integer> nCopies = Collections.nCopies(5, -1);
        Collections.replaceAll(data,"ahmed","hany");
        Collections.reverse(data);
        Collections.rotate(data,1);
        Collections.shuffle(data);
        Collections.swap(data,0,2);
//        Collections.sort(data);
//        Collections.binarySearch()
    }
}
