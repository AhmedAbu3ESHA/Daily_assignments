import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Main10 {
    public static void main(String[] args) {
        List<String> data= Arrays.asList("ahmed","said","tamer");
        ArrayList<String> list=new ArrayList<>();
        Collections.addAll(list,"ahmed","said","hany");
        Collections.reverse(list);
        System.out.println(list);
    }
}
