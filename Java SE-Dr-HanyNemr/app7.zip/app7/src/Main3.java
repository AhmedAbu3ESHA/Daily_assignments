import java.util.ArrayList;

public class Main3 {
    public static void main(String[] args) {
//        String[] data={"ahmed","hany","said"};
        ArrayList<String> data=new ArrayList<>();
        data.add("ahmed");
        data.add("hany");
        data.add("said");
        data.remove("hany");
        data.add(1,"tamer");
        data.set(1,"wael");

        System.out.println(data.get(2));
        System.out.println(data);

    }
}
