public class Main {
    public static void main(String[] args) {
        //ahmed 2000 hany 3200
        String statement="ahmed2000hany3200";
        String[] words=statement.split(" ");
        int sum=0;
        for (int i = 1; i < words.length; i+=2) {// i=0,1,2,3,4,5,6
            sum=sum+Integer.parseInt(words[i]);
        }
        System.out.println("sum="+sum);
    }
}