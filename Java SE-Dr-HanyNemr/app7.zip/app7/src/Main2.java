import java.util.Arrays;

public class Main2 {
    public static void main(String[] args) {
        String statement="ahmed3200hany2000";
        String s="0";
        int sum=0;
        StringBuilder result= new StringBuilder();//3200 2000
        for (int i = 0; i < statement.length(); i++) {
            if(Character.isDigit(statement.charAt(i)))
                s+=statement.charAt(i);
//                result.append(statement.charAt(i));
            else{
                sum += Integer.parseInt(s);
                s="0";
            }
//                result.append(" ");
        }

        sum+=Integer.parseInt(s);
        System.out.println(sum);


//        String[] data=result.toString().split(" ");
//        System.out.println(Arrays.toString(data));
//        int sum=0;
//        for (int i = 0; i < data.length; i++) {
//            if(!data[i].isEmpty())
//                sum+=Integer.parseInt(data[i]);
//        }
//        System.out.println(sum);

    }
}
