import java.util.Arrays;
import java.util.List;

public class Main6 {
    public static void main(String[] args) {
        String[] data={"wael","ahmed","said"};
        List<String> result = Arrays.asList(data);
        String[] copy = Arrays.copyOf(data, data.length);
        Arrays.fill(copy,"");
        System.out.println(Arrays.toString(data));
        System.out.println(Arrays.toString(copy));
//        Arrays.sort(data);
//        System.out.println(Arrays.binarySearch(data, "said"));
        System.out.println(Arrays.toString(data));

    }
}
