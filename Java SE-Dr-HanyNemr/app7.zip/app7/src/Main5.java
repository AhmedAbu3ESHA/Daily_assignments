import java.util.ArrayList;
import java.util.List;

public class Main5 {
    public static void main(String[] args) {
        String[] ar={"ahmed","hany","wael"};

        ArrayList<String> arList=new ArrayList<>();
        arList.add("ahmed");
        arList.add("hany");
        arList.add("wael");

        List<String> list=List.of("ahmed","hany","wael");

    }
}
