package org.example;

public class Main {
    public static void main(String[] args) {
//        Course c = new Course(1, "java", 20000, 100);
//        Course d=new Course(2,"business",20000,30);
        Course[] courses={
                new Course(1, "java", 20000, 100)
                ,new Course(2,"business",20000,30)};
        Student obj1=new Student(1,"mike",24);
        obj1.addCourse(new Course(1,"java",20000,100));
        obj1.addCourse(new Course(2,"business",30000,30));
        obj1.details();

    }
}