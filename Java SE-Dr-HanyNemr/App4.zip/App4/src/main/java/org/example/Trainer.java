package org.example;

public final class Trainer extends Person{

    private String specialty;

    public Trainer(String name, int age, String specialty) {
        super(name, age);
        this.specialty = specialty;
    }

    public Trainer() {
    }

    @Override
    public void eat() {
        System.out.println("trainer is eating");
    }

    public void teach() {
        System.out.println("teaching");
    }


}
