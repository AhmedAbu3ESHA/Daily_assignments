package org.example;

public class Course {
    private int courseID;
    private String name;
    private int cost,duration;

    public int getCourseID() {
        return courseID;
    }

    public void setCourseID(int courseID) {
        this.courseID = courseID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public Course(int courseID, String name, int cost, int duration) {
        this.courseID = courseID;
        this.name = name;
        this.cost = cost;
        this.duration = duration;
    }

    public Course() {
    }

    public void startCourse(){
        System.out.println("starting course");
    }
    public void finishCourse(){
        System.out.println("finishing course");
    }
}
