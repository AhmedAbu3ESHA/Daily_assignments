package org.example;

public final class Student extends Person{

    private int studentID;
    private Course[] courses=new Course[10];
    int index=0;

    public Student(int studentID,String name, int age) {
        super(name, age);
        this.studentID = studentID;
    }

    public Student() {
    }

    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    @Override
    public void eat() {
        System.out.println("student eating");
    }

    public void learn() {
        System.out.println("learning");
    }

    public void addCourse(Course course){
        if(index<courses.length){
            courses[index]=course;
            index++;
        }
    }
    public void removeCourse(Course course){
        for (int i = 0; i < index; i++) {
            if(courses[i].getCourseID()==course.getCourseID()){
                courses[i]=courses[index];
                index--;
                break;
            }
        }

    }
    public void details(){
        for (int i = 0; i < index; i++) {
            System.out.println(getName()+" "+courses[i].getName()+" with price "+courses[i].getCost());
        }
//        for (Course course : courses) {
//            System.out.println(getName()+" "+course.getName()+" with cost "+course.getCost());
//        }
    }
}
