public class Main6 {
    public static void main(String[] args) {
        String statement="i love java i love backend";
        StringBuilder str= new StringBuilder(statement);
        str.reverse();
//        for (int i = statement.length()-1; i >=0 ; i--) {
//            reverse.append(statement.charAt(i));
//        }
        System.out.println(str);
    }
}
