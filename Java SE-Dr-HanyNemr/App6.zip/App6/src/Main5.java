public class Main5 {
    public static void main(String[] args) {
        //casting between numbers
//        byte a=100;
//        byte b=100;
//        byte c= (byte) (a+b);

        //parsing string to number
//        String s="20";
//        int a= Integer.parseInt(s);
//        a=Integer.valueOf(a);
//        System.out.println(a);

        //stringify
//        int a=20;
//        String s=String.valueOf(a);
//        String s=""+a;





    }
}
