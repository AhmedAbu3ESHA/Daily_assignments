public class Main3 {
    public static void main(String[] args) {
        String statement="i love java i love backend";
        String[] split = statement.split(" ");
        for (int i = 0; i < split.length; i++) {
            System.out.println(split[i]+" "+split[i].length());
        }

    }
}
