public class Main4 {
    public static void main(String[] args) {
        String statement="i love java i love backend";
        //solution1
//        char[] chars = statement.toCharArray();
//        byte count=0;
//        for (int i = 0; i < chars.length; i++) {
//            if(chars[i]==' ') count++;
//        }
//        System.out.println("spaces="+count);

        //solution2
//        byte count=0;
//        for (int i = 0; i < statement.length(); i++) {
//            if(statement.charAt(i)==' ') count++;
//        }
//        System.out.println("spaces="+count);

        //solution3
//        String[] split=statement.split(" ");
//        System.out.println("spaces="+(split.length-1));

        //solution4
        String replaced = statement.replaceAll(" ", "");
        int count=statement.length()-replaced.length();
        System.out.println("spaces="+count);


    }
}
