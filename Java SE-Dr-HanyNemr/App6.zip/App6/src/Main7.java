public class Main7 {
    public static void main(String[] args) {
        String a="ahmed246wael3000";
        int sum=0;
        for (int i = 0; i < a.length(); i++) {
            if (Character.isDigit(a.charAt(i))) {
                int b=Character.getNumericValue(a.charAt(i));
                sum = sum + b;
//                System.out.println(a.charAt(i));
//                String c = String.valueOf(a.charAt(i));
//                int b = Integer.parseInt(c);
            }

        }
        System.out.println(sum);

    }
}
