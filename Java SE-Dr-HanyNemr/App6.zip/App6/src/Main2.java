public class Main2 {
    public static void main(String[] args) {
        StringBuilder sb=new StringBuilder("ahmed");
        sb.append("hassan").append("mahmoud");
        String result=sb.toString();

    }
}
