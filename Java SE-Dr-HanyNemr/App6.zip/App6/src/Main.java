import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
       String s="hany nemr";
       //charat
        for (int i = s.length()-1; i >=0 ; i--) {
            System.out.println(s.charAt(i));
        }
        //indexof-lastIndexOf
        System.out.println(s.indexOf("ny"));

        //contains-endsWith-startsWith
        if(s.endsWith("ha")){

        }

        //toUpperCase-toLowerCase
//        s= s.toUpperCase();
        System.out.println(s);
        System.out.println(s.toLowerCase());
        System.out.println(s);

        s=s.replace('h','k');
        System.out.println(s);

        String[] split = s.split(" ");
        for (String s1 : split) {
            System.out.println(s1);
        }
        String a= s.substring(0,3);
        System.out.println(a);
        char[] chars = s.toCharArray();
        for (char aChar : chars) {
            System.out.println(aChar);
        }

        String r="mr.hany";
        String prefix=r.substring(0,r.indexOf("."));
        r=r.substring(prefix.length()+1)+"."+prefix;
        System.out.println(r);
//        String[] result=r.split("\\.");//0 hany 1 mr
//        String prefix=result[0];//mr
//        result[0]=result[1];
//        result[1]=prefix;
//        System.out.println(result[1]+"."+result[0]);
//        String[] result=r.split(" ");
//        System.out.println(result[0]);
//
//        int index=r.indexOf(" ");
//        System.out.println(r.substring(0,index));
//        System.out.println(r.substring(index+1));






    }
}