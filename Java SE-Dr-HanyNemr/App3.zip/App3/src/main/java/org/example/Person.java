package org.example;

public abstract class Person {
    private String name;
    private int age;

    public static final int PARENTS=2;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public Person() {
        name="";
        age=1;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if(age>0)
            this.age = age;
    }

    public abstract void eat();

    public void drink(){
        System.out.println("drinking");
    }

    public void drink(String juice){
        System.out.println("drinking "+juice);
    }

    public final void pray(){
        System.out.println("praying");
    }

}
