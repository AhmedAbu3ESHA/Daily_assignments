package org.example;

public class Main {
    public static void main(String[] args) {

        //student smaller-person bigger
        //double bigger-int smaller
        Student s=new Student("hany",20,"java");
        Trainer t=new Trainer("ahmed",30,"dev");
        letMeEat(s);
        letMeEat(t);



//        Student s=new Student("mike",20,"java");
//        s=new Student("hany",30,"java");
//        s.eat();

//        Trainer t=new Trainer("hany",38,"dev");
//        t.eat();
//        t.teach();


    }

    public static void letMeEat(Person p){
        p.eat();
    }



}