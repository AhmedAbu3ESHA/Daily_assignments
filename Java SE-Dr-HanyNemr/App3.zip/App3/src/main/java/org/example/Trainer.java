package org.example;

public final class Trainer extends Person{
    private String specialty;

    public Trainer(String name, int age, String specialty) {
        super(name, age);
        this.specialty = specialty;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    @Override
    public void eat() {
//        super.eat();
        System.out.println(getName()+" eating slowly");
    }

    public void teach(){
        System.out.println("teaching");
    }
}
