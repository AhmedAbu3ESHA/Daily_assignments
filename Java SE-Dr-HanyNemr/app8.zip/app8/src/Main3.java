import java.util.*;

public class Main3 {
    public static void main(String[] args) {
        List<String> data=List.of("ahmed","said","ahmed","tamer","wael","mahmoud","wael");
        HashSet<String> h = new HashSet<>(data);
        for (String s : h) {
            System.out.println(s);
        }

        HashMap<String,String> map=new HashMap<>();
        map.put("egypt","cairo");
        map.put("usa","ws");
        map.put("france","paris");

//        HashMap<String,List<String>> map=new HashMap<>();
//        map.put("egypt", List.of("cairo","alex"));
//        map.put("usa","ws");
//        map.put("france","paris");

        System.out.println(map.get("egypt"));

        for (String key : map.keySet()) {
            System.out.println(key+" "+map.get(key));
        }

        for (String value : map.values()) {
            System.out.println(value);
        }

        for (Map.Entry<String, String> entry : map.entrySet()) {
            System.out.println(entry.getKey()+" "+entry.getValue());
        }

//        if (map.containsKey("egypt"))

//        if (map.containsValue("paris"))




    }
}
