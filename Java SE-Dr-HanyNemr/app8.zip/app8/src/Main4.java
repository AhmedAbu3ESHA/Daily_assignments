import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main4 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        HashMap<String, String> data = new HashMap<>();
        data.put("saw", "horror");
        data.put("expendables", "action");
        data.put("it", "horror");
        data.put("up", "animation");
        data.put("ride", "comedy");

        HashMap<String,Integer> frequencies=new HashMap<>();

        while (true){
            System.out.println("enter input");
            String input =s.next();
            if (input.equals("exit")) break;

            if(data.containsKey(input)){
                System.out.println(data.get(input));
                frequencies.put(input,frequencies.getOrDefault(input,0)+1);
            }else if (data.containsValue(input)){
                for (Map.Entry<String, String> entry : data.entrySet()) {
                    if(entry.getValue().equals(input))
                        System.out.println(entry.getKey());
                }
            }
        }
        for (Map.Entry<String, Integer> entry : frequencies.entrySet()) {
            System.out.println(entry.getKey()+" "+entry.getValue());
        }

        int max= Collections.max(frequencies.values());
        for (Map.Entry<String, Integer> entry : frequencies.entrySet()) {
            if(entry.getValue()==max){
                System.out.println(entry.getKey());
                break;
            }
        }
    }
}
