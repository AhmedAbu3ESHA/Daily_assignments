import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main2 {
    public static void main(String[] args) {
        List<String> names=List.of("ahmed","said","wael","tamer");
        List<String> phones=List.of("010","011","012","015");

        List<Integer> frequencies= new ArrayList<>(Collections.nCopies(names.size(), 0));

        Scanner s = new Scanner(System.in);

        while (true){
            System.out.println("enter input");
            String input=s.next();
            if (input.equals("exit")) break;

            if (names.contains(input)){
                int index=names.indexOf(input);
                System.out.println(phones.get(index));
                frequencies.set(index,frequencies.get(index)+1);
            }else if (phones.contains(input)){
                int index=phones.indexOf(input);
                System.out.println(names.get(index));
            }else{
                System.out.println("wrong");
            }
        }

        int max=Collections.max(frequencies);
        int index=frequencies.indexOf(max);
        System.out.println("max search is "+names.get(index));

        for (int i = 0; i < names.size(); i++) {
            System.out.println(names.get(i)+" "+frequencies.get(i));
        }

//        ArrayList<Integer> freqs=new ArrayList<>();
//        for (String name : names) {
//            int f= Collections.frequency(user,name);
//            freqs.add(f);
//        }
//        int max=Collections.max(freqs);
//        int index=freqs.indexOf(max);
//        System.out.println("max seach is "+names.get(index));

    }
}
