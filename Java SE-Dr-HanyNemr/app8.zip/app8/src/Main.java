import java.util.*;

public class Main {
    public static void main(String[] args) {
        List<String> names=List.of("ahmed","said","wael","tamer");
        List<String> phones=List.of("010","011","012","015");
        ArrayList<String> user=new ArrayList<>();

        Scanner s = new Scanner(System.in);

        while (true){
            System.out.println("enter input");
            String input=s.next();
            if (input.equals("exit")) break;

            if (names.contains(input)){
                int index=names.indexOf(input);
                System.out.println(phones.get(index));
                user.add(input);
            }else if (phones.contains(input)){
                int index=phones.indexOf(input);
                System.out.println(names.get(index));
            }else{
                System.out.println("wrong");
            }
        }

        ArrayList<Integer> freqs=new ArrayList<>();
        for (String name : names) {
            int f=Collections.frequency(user,name);
            freqs.add(f);
        }
        int max=Collections.max(freqs);
        int index=freqs.indexOf(max);
        System.out.println("max seach is "+names.get(index));

    }
}