import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
//        ArrayList<String> data=new ArrayList<>();
//        try {
//            data.set(1,"asdsa");
//        } catch (IndexOutOfBoundsException e) {
//            System.out.println("error");
//        }

//        try {
//            FileReader f=new FileReader("c:\\test.txt");
//        } catch (FileNotFoundException e) {
//            System.out.println("error");
//        }

        try {
            readFile();
        } catch (FileNotFoundException e) {
            System.out.println("error");
        }catch (Exception e){
            System.out.println(e.getMessage());
        }

        try {
            sum(-5,-6);
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void sum(int a,int b){
        if (a<0 || b<0){
            throw new IllegalArgumentException("numbers must be greater than zero");
        }
        System.out.println(a+b);
    }

    public static void readFile() throws FileNotFoundException {
        FileReader f=new FileReader("c:\\test.txt");
    }
}