import java.io.*;
import java.util.Scanner;

public class Main3 {
    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);
        System.out.println("enter data");
        String data=s.next();

        try (FileWriter fileWriter=new FileWriter("data.txt",true);
             BufferedWriter br=new BufferedWriter(fileWriter);){
            br.write("ahmed hassan");
            br.newLine();
            br.write("25 years");
            br.newLine();
        } catch (IOException e) {

        }

    }

    private static void readFile() {
        try (
                FileReader fileReader=new FileReader("data.txt");
                BufferedReader br=new BufferedReader(fileReader);
        ){

            while (true){
                String line = br.readLine();
                if (line==null) break;
                System.out.println(line);
            }
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
