public enum ErrorCodes {
    NegativeDeposit,
    InsufficientBalance,
}
