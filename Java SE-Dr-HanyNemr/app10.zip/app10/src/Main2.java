public class Main2 {
    public static void main(String[] args) {
        Account account=new Account("ahmed",5000);
        try {
            account.withdraw(2000);
            account.deposit(-2000);
        } catch (AccountException e) {
            System.out.println(e.getMessage());
        }


    }
}
