import java.util.HashMap;

public class AccountException extends Exception{

    private ErrorCodes code;
    private static HashMap<ErrorCodes,String> messages=new HashMap<>();

    static{
        messages.put(ErrorCodes.NegativeDeposit,"message1");
        messages.put(ErrorCodes.InsufficientBalance,"message2");
    }


    public AccountException(ErrorCodes code) {
        this.code = code;
    }

    @Override
    public String getMessage() {
        return messages.get(code);
    }
}
