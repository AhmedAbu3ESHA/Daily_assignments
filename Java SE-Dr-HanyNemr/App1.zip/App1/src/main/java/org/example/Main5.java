package org.example;

import java.util.Scanner;

public class Main5 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        byte score = 0;
        String[] countries = {"egypt", "usa", "uk", "france"};
        String[] cities = {"cairo", "ws", "london", "paris"};
        for (int i = 0; i < countries.length; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.println("what is the capital of " + countries[i]);
                String answer = s.next();
                if (answer.equalsIgnoreCase(cities[i])) {
                    score++;
                    break;
                }
            }
        }
        System.out.println("score=" + score);
    }
}
