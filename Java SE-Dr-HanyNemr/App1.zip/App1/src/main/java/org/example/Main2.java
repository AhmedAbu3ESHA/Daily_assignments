package org.example;

import javax.annotation.processing.SupportedAnnotationTypes;
import java.util.Scanner;

public class Main2 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("enter amount");
        int amount=s.nextInt();
        int base=amount;
        System.out.println("enter limit");
        int limit=s.nextInt();
        if(amount>limit){
            System.out.println("wrong data");
            return;
        }
        System.out.println("enter percent");
        byte percent=s.nextByte();
        if(percent>30){
            System.out.println("wrong percent");
            return;
        }
        byte year=0;
        while (amount<limit){
            year++;
            int increase=amount*percent/100;
            amount=amount+increase;
        }
        System.out.println("ur money will be " + amount + " after " + year);
        if(year>5){
            int increase=amount*10/100;
            amount=amount+increase;
            System.out.println("ur money will be "+amount+" GOLD Customer");
        }
    }
}
