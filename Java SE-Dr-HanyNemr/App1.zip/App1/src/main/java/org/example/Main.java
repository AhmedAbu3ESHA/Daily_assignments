package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("what is ur name");
        String name=s.next();
        System.out.println("what time of day are we");
        String time=s.next();
        String output;
        if (time.equalsIgnoreCase("morning")
                || time.equalsIgnoreCase("evening"))
            output="good "+time+" "+name;
        else
            output="hi "+name;
        System.out.println("how old are u");
        byte age=s.nextByte();
        System.out.println(output);
        if(age<=0)
            System.out.println("wrong");
        else if(age>=20 && age<=30)
            System.out.println("young");
        else if (age>30)
            System.out.println("old");
        else
            System.out.println("very young");

    }
}