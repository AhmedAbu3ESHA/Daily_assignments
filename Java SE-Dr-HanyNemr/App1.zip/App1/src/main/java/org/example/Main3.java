package org.example;

import java.util.Scanner;

public class Main3 {
    public static void main(String[] args) {

        String[] names={"ahmed","tamer","alaa"};
        for (int i = 0; i < names.length; i++) {
            if(names[i].equalsIgnoreCase("tamer"))
                System.out.println("welcome "+names[i]);
            else
                System.out.println("hello "+names[i]);
        }

    }
}
