package org.example;

import java.util.Scanner;

public class Main4 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        byte score=0;
        String[] countries={"egypt","usa","uk","france"};
        String[] cities={"cairo","ws","london","paris"};
        byte lives=0;
        for (int i = 0; i < countries.length; i++) {
            System.out.println("what is the capital of "+countries[i]);
            String answer = s.next();
            if (answer.equalsIgnoreCase(cities[i])) {
                score++;
                lives=0;
            }
            else {
                lives++;
                if(lives==3){
                    lives=0;
                }else
                    i--;
            }


//            else
//                score--;
//
//            if(score<0 && i>0){
//                System.out.println("game over");
//                score=0;
//                break;
//            }
        }

        System.out.println("score="+score);


    }
}
