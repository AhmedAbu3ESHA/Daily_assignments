package org.example;

import java.util.Scanner;

public class Main2 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        String[] egypt = {"cairo", "alex", "aswan", "giza", "banha"};
        String[] copy = {"cairo", "alex", "aswan", "giza", "banha"};
        byte[] scores=new byte[2];

        startGame(s, egypt, copy, scores);

        //winner (max)
        Winner(scores);


        //solution1
//        Scanner s = new Scanner(System.in);
//        byte score=0;
//        boolean[] tried=new boolean[5];
//        String[] egypt = {"cairo", "alex", "aswan", "giza", "banha"};
//        System.out.println("guess 3 cities in egypt");
//        for (int k = 0; k < 3; k++) {
//            String answer=s.next();
//            for (int i = 0; i < egypt.length; i++) {
//                if(answer.equalsIgnoreCase(egypt[i]) && tried[i]==false){
//                    score++;
//                    tried[i]=true;
//                    break;
//                }
//            }
//        }
//        System.out.println("score="+score);

    }

    private static void startGame(Scanner s, String[] egypt, String[] copy, byte[] scores) {
        for (int j = 0; j < 2; j++) { //players
            byte score=0;
            System.out.println("player "+(j+1));
            System.out.println("guess 3 cities in egypt");
            for (int k = 0; k < 3; k++) { //trials
                String answer= s.next();
                for (int i = 0; i < egypt.length; i++) { //search
                    if(answer.equalsIgnoreCase(egypt[i])){
                        score++;
                        egypt[i]="";
                        break;
                    }
                }
            }
            System.out.println("score="+score);
            scores[j]=score;
            reset(egypt, copy);

        }
    }

    private static void Winner(byte[] scores) {
        int max= scores[0];
        int index=0;
        for (int i = 0; i < scores.length; i++) {
            if(scores[i]>max){
                max= scores[i];
                index=i;
            }
        }

        //count
        int count=0;
        for (int i = 0; i < scores.length; i++) {
            if(scores[i]==max) count++;
        }
        if(count>1)
            System.out.println("no winner");
        else
            System.out.println("the winner is player "+(index+1));
    }

    private static void reset(String[] egypt, String[] copy) {
        for (int i = 0; i < egypt.length; i++) {
            egypt[i]= copy[i];
        }
    }
}
