package org.example;

public class Operation {
    int a,b;
    public void sum() {
        int c= a + b;
        System.out.println(c);
    }

    public void subtract(){
        int c= a + b;
        System.out.println(c);
    }
}
