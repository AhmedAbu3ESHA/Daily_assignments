package org.example;

public class Main3 {
    public static void main(String[] args) {


        Operation o=new Operation();
        o.a=5;
        o.b=10;
        o.sum();
        o.subtract();

        //code

        o.a=5;
        o.b=8;
        o.sum();
    }


}
