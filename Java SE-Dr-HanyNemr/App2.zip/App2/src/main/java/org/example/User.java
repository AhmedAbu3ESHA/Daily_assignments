package org.example;

public class User {
     private String name,time;
     private byte age;

     public final static String work="bm";

    public User(String name, String time, byte age) {
        this.name = name;
        this.time = time;
        this.age = age;
    }

    public User() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public byte getAge() {
        return age;
    }

    public void setAge(byte age) {
        this.age = age;
    }

    public void checkTime(){
        if(time.equalsIgnoreCase("morning")
                || time.equalsIgnoreCase("evening"))
            System.out.println("good "+time+" "+name);
        else
            System.out.println("hi "+name);
    }

    public void checkAge(){
        if (age>30)
            System.out.println("old");
        else
            System.out.println("young");
    }
}
