package org.example;

public class Main4 {
    public static void main(String[] args) {

        Operation o=new Operation();
        o.a=5;
        o.b=10;
        o.sum();
        //code

        o.a=8;
        o.b=4;
        o.sum();
    }


}
