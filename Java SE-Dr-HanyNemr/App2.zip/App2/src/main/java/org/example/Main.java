package org.example;

public class Main {
    public static void main(String[] args) {
        //count
        int[] ages={20,25,20,10,20};
        int count=0;
        for (int i = 0; i < ages.length; i++) {
            if(ages[i]==20) count++;
        }
        System.out.println(count);










        //max ->0
//        int[] ages={20,23,15,10};
//        int max=ages[0];
//        int index=0;
//        for (int i = 1; i < ages.length; i++) {
//            if(ages[i]>max){
//                max=ages[i];
//                index=i;
//            }
//        }
//        System.out.println("max="+max);
//        System.out.println("max index="+index);













        //search
        String[] names={"ahmed","hany","tamer","alaa","wael"};
        for (int i = 0; i < names.length; i++) {
            if(names[i].equals("sadsa")){
                System.out.println("found");
                break;
            }
            else if(i==names.length-1)
                System.out.println("not found");
        }



//        String[] names={"ahmed","hany","tamer","alaa","wael"};
//        boolean found=false;
//        for (int i = 0; i < names.length; i++) {
//            if(names[i].equals("sadsa")){
//                System.out.println("found");
//                found=true;
//                break;
//            }
//        }
//        if(!found){
//            System.out.println("not found");
//        }
    }
}