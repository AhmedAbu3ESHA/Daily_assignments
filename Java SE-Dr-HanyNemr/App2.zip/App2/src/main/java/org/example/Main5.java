package org.example;

import java.util.Scanner;

public class Main5 {
    public static void main(String[] args) {

        User u1=new User("ahmed","morning", (byte) 20);
        User u2=new User();
        u2.setName("wael");


//        Scanner s=new Scanner(System.in);
//        User u=new User();
//        System.out.println("what is ur name");
//        u.setName(s.next());
//        System.out.println("what time of day are we");
//        u.setTime(s.next());
//        u.checkTime();
//        System.out.println("how old are u");
//        u.setAge(s.nextByte());
//        u.checkAge();
//
//        System.out.println(u.getAge());
//        System.out.println(u.work);
    }
}
