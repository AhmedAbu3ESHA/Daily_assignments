import javax.annotation.processing.SupportedAnnotationTypes;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String[] names={"ahmed","said","tamer"};
        try {
            for (int i = 0; i < 4; i++) {
                System.out.println(names[i]);
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Error");
        }

//        ArrayList<String> data;
//        try {
//            if (data.size()>0)
//                data.set(2,"ahmed");
//        } catch (NullPointerException e) {
//            System.out.println("error");
//        }

//        try {
//            int a=5;
//            int b=0;
//            double result = a / b;
//            System.out.println(result);
//        } catch (ArithmeticException e) {
//            System.out.println("division error");;
//        }


//        ArrayList<String> data;
//        if(data!=null){
//            data=new ArrayList<>();
//            data.add("ahmed");
//        }

//        try {
//            Scanner s = new Scanner(System.in);
//            System.out.println("enter number");
//            int number=s.nextInt();
//            number++;
//            System.out.println(number);
//        } catch (InputMismatchException e) {
//            System.out.println("pleaes enter numbers only");;
//        }

        try {
            FileReader f=new FileReader("c\\test.txt");
        } catch (FileNotFoundException e) {
            System.out.println("file not found");
        }

    }
}