import java.io.FileNotFoundException;
import java.io.FileReader;

public class Main2 {
    public static void main(String[] args) {
        try {
            readFile();
            System.out.println(5/0);
        } catch (FileNotFoundException e) {
            System.out.println("file not found");
        } catch (ArithmeticException e){
            System.out.println("division error");
        }
    }

    public static void readFile() throws FileNotFoundException {
        FileReader f=new FileReader("c\\test.txt");

    }
}
