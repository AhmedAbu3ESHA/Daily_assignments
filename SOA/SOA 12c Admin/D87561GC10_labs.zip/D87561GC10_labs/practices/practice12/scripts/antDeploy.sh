# ===============================================
# antDeploy.sh
# version 1.0.0 2015.05.09
# D87561GC10 Oracle SOA Suite 12c: Administration
# practice 12
# ===============================================

# ===================================================================
# This generic routine displays passed text and supresses
# the newline character. This is NOT specific to the ant script.
#===================================================================

prompt()
{
if [ "`echo -n`" = "-n" ]
	then
		 C='\c'
		 N=
	else
		 C=
		 N=' -n'
	fi
echo $N " $1 $C"
}

setVariables()
{
# ==============================================================
# SET ANT COMMAND LOCATION
# ==============================================================
	MW_HOME=/u01/oracle/product/fmw
	ANT_HOME=$MW_HOME/oracle_common/modules/org.apache.ant_1.9.2/bin
	ANT_CMD=$ANT_HOME/ant

# ==============================================================
# SET ANT PARAMETERS
# ==============================================================
	ANT_SCRIPT=$MW_HOME/soa/bin/ant-sca-deploy.xml
	SERVER_URL=http://soainternal.example.com:8080
	SAR_LOCATION=../deploy/sca_Approval_rev2.0.jar
	OVERWRITE=true
	USER=weblogic
	PARTITION=default
#	FORCE_DEFAULT=true
}

# ==============================================================
# DISPLAY ANT COMMAND LINE VALUES
# ==============================================================

display()
{
  clear
  echo
  echo " $0"
  echo --------------------------------------
  echo " MW_HOME       $MW_HOME"
  echo " ANT_HOME      $ANT_HOME"
  echo " ANT_SCRIPT    $ANT_SCRIPT"
  echo --------------------------------------
  echo " SERVER_URL    $SERVER_URL"
  echo " SAR_LOCATION  $SAR_LOCATION"
  echo " OVERWRITE     $OVERWRITE"
  echo " USER          $USER"
  echo " PARTITION     $PARTITION"
  echo " FORCE_DEFAULT $FORCE_DEFAULT"
  echo " PASSWORD      $PASSWORD"
  echo --------------------------------------
  echo " COMMAND LINE: ant -f ant-sca-deploy.xml  -DserverURL=$SERVER_URL -DsarLocation=$SAR_LOCATION -Doverwrite=$OVERWRITE -Dpartition=$PARTITION -Duser=$USER"
}

# ==============================================================
# INVOKE ANT
# ==============================================================

invokeScript()
{
	echo "You are about to execute the following command:"
	display
	echo --------------------------------------
	prompt "Press any key when ready: "
	read ANYKEY
	$ANT_CMD -f $ANT_SCRIPT -DserverURL=$SERVER_URL -DsarLocation=$SAR_LOCATION -Doverwrite=$OVERWRITE -Dpartition=$PARTITION -Duser=$USER
}

setVariables
invokeScript

