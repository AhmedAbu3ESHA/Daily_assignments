# ===============================================
# undeployHelloWorld.sh
# version 1.0.0 2015.04.28
# Oracle SOA Suite 12c: Administration
# practice 08
# ===============================================


# file names and locations
MW_HOME=/u01/oracle/product/fmw
ANT_HOME=$MW_HOME/oracle_common/modules/org.apache.ant_1.9.2/bin
ANT_CMD=$ANT_HOME/ant

ANT_SCRIPT=$MW_HOME/soa/bin/ant-sca-deploy.xml

# script parameters
ACTION=undeploy
SERVER_URL=
COMPOSITE_NAME=
REVISION=

# invoking the script
$ANT_CMD -f $ANT_SCRIPT $ACTION -DserverURL=$SERVER_URL -DcompositeName=$COMPOSITE_NAME -Drevision=$REVISION

