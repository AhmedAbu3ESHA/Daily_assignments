# ===============================================
# makeData.sh
# version 1.0.0 2015.04.28
# D87561GC10 Oracle SOA Suite 12c: Administration
# practice 10
# ===============================================


# this loop will generate 60 input files--one every 10 seconds for 10 minutes
# every 20th file will cause a fault to be thrown by the BookingSystem application

# if [ "X$1" != "X" ]
# then
# numMsg=$1
# else
# numMsg=2
# fi

for i in {1..60}
do
timestamp=`date '+%Y%m%d%H%M%S'`

n=$((i%20))
if [ "$n" -eq 0 ] 
then
 source=./xml/enrollment_fault.xml
 target=../input/enrollment_fault_$timestamp.xml
else
 source=./xml/enrollment_input.xml
 target=../input/enrollment_input_$timestamp.xml
fi
cp $source $target
  sleep 10
done

