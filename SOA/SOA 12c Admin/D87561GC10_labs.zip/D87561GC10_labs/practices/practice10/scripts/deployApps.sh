# ===============================================
# deployApps.sh
# version 1.0.0 2015.04.28
# D87561GC10 Oracle SOA Suite 12c: Administration
# practice 10
# ===============================================

# these variables store locations, including that of the ant command
MW_HOME=/u01/oracle/product/fmw
ANT_HOME=$MW_HOME/oracle_common/modules/org.apache.ant_1.9.2/bin
ANT_CMD=$ANT_HOME/ant

# these variables store the ant script and related parameters
ANT_SCRIPT=$MW_HOME/soa/bin/ant-sca-deploy.xml
SERVER_URL=http://soainternal.example.com:8080
OVERWRITE=true

# deploy the first application
SAR_LOCATION=../deploy/sca_BookingSystem_rev1.0.jar
$ANT_CMD -f $ANT_SCRIPT -DserverURL=$SERVER_URL -DsarLocation=$SAR_LOCATION -Doverwrite=$OVERWRITE

# deploy the second application
SAR_LOCATION=../deploy/sca_Enroll_rev1.0.jar
$ANT_CMD -f $ANT_SCRIPT -DserverURL=$SERVER_URL -DsarLocation=$SAR_LOCATION -Doverwrite=$OVERWRITE
