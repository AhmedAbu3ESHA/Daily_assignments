# ===============================================
# antPartitions.sh
# version 1.0.0 2015.04.28
# D87561GC10 Oracle SOA Suite 12c: Administration
# practice 09
# ===============================================


# ----- displays text; supress newline char ----------------------------

prompt()
{
  echo $N " $1 $C"
}


# ------ display -------------------------------------------------------

display()
{
  clear
  echo
  echo " $0"
  echo --------------------------------------
  echo " MW_HOME       $MW_HOME"
  echo " ANT_HOME      $ANT_HOME"
  echo " ANT_SCRIPT    $ANT_SCRIPT"
  echo --------------------------------------
  echo " ACTION        $ACTION"
  echo --------------------------------------
  echo " HOST          $HOST"
  echo " PORT          $PORT"
  echo " USER          $USER"
  echo " PASSWORD      $PASSWORD"
  echo " PARTITION     $PARTITION"
  echo --------------------------------------
  echo " COMMAND LINE: ant -f ant-sca-mgmt.xml $ACTION -Dhost=$HOST -Dport=$PORT -Duser=$USER -Dpartition=$PARTITION"

}


setVariables()
{
# ==============================================================
# SET newline CHARACTER to support prompt() subroutine
# ==============================================================

if [ "`echo -n`" = "-n" ]
then
   C='\c'
   N=
else
   C=
   N=' -n'
fi

# ==============================================================
# SET ant VALUES
# these variables store locations, including that of the ant command 
# ==============================================================
	MW_HOME=/u01/oracle/product/fmw
	ANT_HOME=$MW_HOME/oracle_common/modules/org.apache.ant_1.9.2/bin
	ANT_CMD=$ANT_HOME/ant

# ==============================================================
# SET SCRIPT VALUES
# these variables store the ant script and related parameters
# ==============================================================
	ANT_SCRIPT=$MW_HOME/soa/bin/ant-sca-mgmt.xml
	HOST=soavh01.example.com
	PORT=8001
	USER=weblogic
#	PASSWORD=Welcome1
	PARTITION=myPartition	
	ACTION=NONE
}

invokeScript()
{
	echo "You are about to execute the following command:"
	display 
	echo --------------------------------------
	prompt "Press any key when ready: "
	read ANYKEY
	$ANT_CMD -f $ANT_SCRIPT $ACTION -Dhost=$HOST -Dport=$PORT -Duser=$USER -Dpartition=$PARTITION
}



# ------ menu loop ------------------------------------------------------

main()
{
  setVariables
  while :
  do
    clear
		echo  ------------------------------------------------------------------------------
		echo " D87561GC10 Oracle SOA Suite 12c: Administration"
		echo " practice 09"
    echo " $0                  `date`"
    echo  ------------------------------------------------------------------------------
    echo
    echo " A) Create a partition"
    echo " B) List partitions"
    echo
    echo " C) List composites in partition"
    echo " D) Stop composites in partition"
    echo " E) Start composites in partition"
    echo " F) Retire composites in partition"
    echo " G) Activate composites in partition"
    echo " H) Delete a partition"
    echo
		echo " X) Exit"
    echo

    prompt "Enter your selection: "
    read ANYKEY
    
    case $ANYKEY in
			A | a )
				ACTION=createPartition
			  ;;
			B | b )
				ACTION=listPartitions
			  ;;
			C | c )
				ACTION=listCompositesInPartition
			  ;;
			D | d )
				ACTION=stopCompositesInPartition
			  ;;
			E | e )
				ACTION=startCompositesInPartition
			  ;;
			F | f )
				ACTION=retireCompositesInPartition
			  ;;
			G | g )
				ACTION=activateCompositesInPartition
			  ;;
			H | h )
				ACTION=deletePartition
			  ;;
			X | x )
				exit 0
			  ;;
			*)
			  ;;
    esac
    
		if [ "$ACTION" != "NONE" ]
		then
			invokeScript
            exit 0
		fi
  done
}

main
