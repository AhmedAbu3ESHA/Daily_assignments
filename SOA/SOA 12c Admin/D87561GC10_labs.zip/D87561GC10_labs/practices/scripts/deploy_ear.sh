#!/bin/bash

#path found
#/u01/oracle/product/fmw/wlserver

#export ANT_HOME=/u01/oracle/product/fmw/oracle_common/modules/org.apache.ant_1.9.2
#export PATH=${PATH}:${ANT_HOME}/bin

export SOA_HOME=/u01/oracle/product/fmw/soa
export SERVER_HOME=/u01/oracle/product/fmw/wlserver/server
export PATH=${PATH}:${SERVER_HOME}/lib:${SERVER_HOME}/lib/weblogic.jar
echo "$PATH"
#export SOA_HOST=http://adminvh.example.com:7001
export SOA_HOST=http://soainternal.example.com:8080

export APP_NAME=$1
export PASSWD=$3
export USER=$2

if [ -z "$APP_NAME" ]
then
        echo "To deploy a ear application use the following syntax:"
	echo ". "
	echo "  Usage: deploy_ear.sh app-name "
	echo ". "
        exit 1
fi

export CURR_DIR=$PWD
# Call setDomainEnv here.

DOMAIN_HOME="/u01/oracle/config/domains/edg_domain"

. ${DOMAIN_HOME}/bin/setDomainEnv.sh $*
cd $CURR_DIR
echo "dir : $CURR_DIR"

echo "My domain home : $DOMAIN_HOME"
ant -file /practices/scripts/build12c.xml undeploy -Dapp.name=$APP_NAME -Duser=$USER -Dpassword=$PASSWD -Ddist.dir=$PWD
ant -file /practices/scripts/build12c.xml deploy -Dapp.name=$APP_NAME -Duser=$USER -Dpassword=$PASSWD -Ddist.dir=$PWD



#end
