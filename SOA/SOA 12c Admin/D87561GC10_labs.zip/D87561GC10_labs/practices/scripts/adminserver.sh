#!/bin/bash
# chkconfig: 345 99 10
#
SVCNAME="WebLogic Node Manager"
LOGFILE=/practices/log/$(basename $0 .sh).log
MW_HOME=/u01/oracle/product/fmw
DOMAIN_HOME=/u02/oracle/config/domains/edg_domain
JAVA_HOME=/usr/java/latest
PATH=$JAVA_HOME/bin:$PATH
WLST=/u01/oracle/product/fmw/oracle_common/common/bin/wlst.sh

function mlog() {
  TSTAMP=$(date +"%F %H:%M:%S")
  echo -e "[${TSTAMP}] $1" | tee -a $LOGFILE
}

case "$1" in
start|stop|status)
  $WLST /practices/scripts/adminserver.py $1
  ;;
*)
  echo "Usage: $0 {start|stop|status}"
  exit 3
  ;;
esac
