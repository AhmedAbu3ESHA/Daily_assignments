#!/bin/bash
# Additional options for silent instal
# -printdiskusage -printmemory
source /practices/scripts/setjdk.sh
RESPONSE_FILE=${1:-$(find /practices/practice03/install_fmw_infra.rsp)}
if [ ! -f $RESPONSE_FILE ]; then
   RESPONSE_FILE=/practices/practice03/install_fmw_infra.rsp
fi
echo RESPONSE_FILE=$RESPONSE_FILE
if [ -f $RESPONSE_FILE ]; then
  echo "Executing..."
  echo "java -d64 -jar /install/soa/fmw_12.1.3.0.0_infrastructure.jar -silent -responseFile $RESPONSE_FILE"
  java -d64 -jar /install/soa/fmw_12.1.3.0.0_infrastructure.jar -silent -responseFile $RESPONSE_FILE
else
  echo "Response file '$RESPONSE_FILE' not found."
  echo "Usage: install_infra.sh [response_file_path]"
fi
