#!/bin/bash
DATADIR=${2:-/practices/practice03}
case "$1" in
backup)
  echo "Backing up server authentication configuration files to $DATADIR ..."
  tar cvf $DATADIR/auth_data.tar $ASERVER/config/config.xml $ASERVER/config/fmwconfig/jps-config.xml $ASERVER/config/fmwconfig/system-jazn-data.xml $ASERVER/servers/AdminServer/security/boot.properties
  ;;
restore)
  if [ -f $DATADIR/auth_data.tar  ]; then
     echo "Restoring server authentication configuration files from $DATADIR ..."
     tar xvf $DATADIR/auth_data.tar -C /
  fi
  ;;
*)
  echo "Usage: $0 {backup|restore} [folder-path]"
  exit 3
  ;;
esac
