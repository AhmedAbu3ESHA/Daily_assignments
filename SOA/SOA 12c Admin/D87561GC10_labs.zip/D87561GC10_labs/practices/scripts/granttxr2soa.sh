#!/bin/bash
SQLPLUS=$(find /u01 -type f -name sqlplus)
if [ -z $SQLPLUS ]; then
  echo "Error: SQL*Plus application cannot be found."
  exit 1
fi
${SQLPLUS} "/ as sysdba" <<-END
GRANT SELECT ON sys.dba_pending_transactions TO EDG_SOAINFRA;
GRANT FORCE ANY TRANSACTION TO EDG_SOAINFRA;
EXIT
END
