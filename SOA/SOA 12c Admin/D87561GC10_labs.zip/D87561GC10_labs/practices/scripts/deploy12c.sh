#!/bin/bash

#path found
#/u01/oracle/product/fmw/wlserver


export ANT_HOME=/u01/oracle/product/fmw/oracle_common/modules/org.apache.ant_1.9.2
export PATH=${PATH}:${ANT_HOME}/bin

#echo "$PATH"


export SOA_HOME=/u01/oracle/product/fmw/soa
export SOA_BIN=${SOA_HOME}/bin
#export SOA_HOST=http://adminvh.example.com:7001
export SOA_HOST=http://soainternal.example.com:8080

export SAR_FILE=$1
export CONFIG_PLAN=$3
export PARTITION=$2

if [ -z "$SAR_FILE" ]
then
        echo "To deploy a composite application use the following syntax:"
	echo ". "
	echo "  Usage: deploy12c.sh sar-file-name [partition] [config-plan]"
	echo ". "
	echo "  Revision is derived from the SAR file name. The sar-file-name must be provided."
	echo "  The config-plan is the XML file name for the configuration plan (if any)."
	echo "  The partition is set to 'default' unless specified as the third parameter."
	echo ". "
        exit 1
fi


if [ -z "$PARTITION" ] 
then 
	export PARTITION=default
	echo "Setting Partition : $PARTITION"
fi


if [ -n "$CONFIG_PLAN" ]
then
        export CONFIG_PLAN=-Dconfigplan=$CONFIG_PLAN
        echo "Setting Configuration Plan : $CONFIG_PLAN"
fi
	
	
echo "Final SAR File : ${SAR_FILE}"	
echo "Final Configuration Plan : $CONFIG_PLAN"
echo "Final Partition : $PARTITION"


ant -f $SOA_BIN/ant-sca-deploy.xml -DserverURL=$SOA_HOST -DsarLocation=$SAR_FILE -Doverwrite=true -DforceDefault=true $CONFIG_PLAN -Dpartition=$PARTITION

#end
