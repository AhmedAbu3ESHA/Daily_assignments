#!/bin/bash
cat /practices/scripts/setenv.sh >> $HOME/.bashrc
echo "$HOME/.bashrc updated."
