if len(sys.argv) == 0:
  print "Usage: wlst adminserver.py [start|stop|status]"
  exit()
else:
  if sys.argv[1] != "start" and sys.argv[1] != "stop" and sys.argv[1] != "status":
    print "Usage: wlst adminserver.py [start|stop|status]"
    exit()
  
domain_name="edg_domain"
try:
  domain_path = os.environ["ASERVER"]
except:
  domain_path="/u02/oracle/config/domains/" + domain_name

#lhost=java.net.InetAddress.getLocalHost().getHostName()
lhost="adminvh.example.com"
nmhost=raw_input("Hostname ["+ lhost +"]: ")
if not nmhost:
  nmhost=lhost

luser="weblogic"
nmuser=raw_input("NM Username ["+ luser +"]: ")
if not nmuser:
  nmuser=luser

nmpsw="".join(System.console().readPassword("%s",["NM Password: "]))
if not nmpsw:
   print "Error: Please enter the WebLogic administrator password."
   exit()

#print "Domain: " + domain_path
#print "Host: " + nmhost
#print "User: " + nmuser

bootpfile=domain_path+"/servers/AdminServer/security/boot.properties"
bootpexists=os.path.exists(bootpfile)
if not bootpexists:
  print "Error: "+ bootpfile +" does not exist yet. Please create the file."
  exit()

try:
  # Connect to NodeManager in order to start AdminServer
  nmConnect(nmuser, nmpsw, nmhost, 5556, domain_name, domain_path, 'ssl')

  if sys.argv[1] == "start":
    #Start Admin Server using NodeManager (boot.properties file must exist first)
     nmStart('AdminServer')
     print "AdminServer started."
  elif sys.argv[1] == "stop":
     nmKill('AdminServer')
     print "AdminServer killed or stopped."
  elif sys.argv[1] == "status":
     redirect('/dev/null','false')
     print "AdminServer " + nmServerStatus('AdminServer')
     stopRedirect()
  else:
     print "Error: '" + sys.arv[1] + "' is an invalid command line parameter."

  nmDisconnect()
except:
  print "ERROR... check error messages for cause."

exit()
