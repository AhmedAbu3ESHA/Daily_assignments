export TZ=$(date +%Z%z)
export JAVA_HOME=/usr/java/jdk1.7.0_55
export PATH=$JAVA_HOME/bin:$PATH
#
alias cls=clear
if [ -f /usr/bin/rlwrap ]; then
  RLWRAP=/usr/bin/rlwrap
fi
SQLPLUS=$(find /u01 -type f -name sqlplus)
if [ ! -z $SQLPLUS ]; then
  alias sqlplus="${RLWRAP:+rlwrap }${SQLPLUS}"
fi
RMAN=$(find /u01 -type f -name rman)
if [ ! -z $RMAN ]; then
  alias rman="${RLWRAP:+rlwrap }${RMAN}"
fi
export PS1="\h:\w:\!> "

