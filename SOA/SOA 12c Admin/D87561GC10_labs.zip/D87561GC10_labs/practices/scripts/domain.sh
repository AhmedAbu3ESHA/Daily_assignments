#!/bin/bash
# chkconfig: 345 99 10
#
MW_HOME=/u01/oracle/product/fmw
JAVA_HOME=/usr/java/latest
PATH=$JAVA_HOME/bin:$PATH
WLST=/u01/oracle/product/fmw/oracle_common/common/bin/wlst.sh

case "$1" in
startup)
  $WLST /practices/scripts/domain.py start
  ;;
shutdown)
  $WLST /practices/scripts/domain.py stop
  ;;
*)
  echo "Usage: $0 {startup|shutdown}"
  exit 1
  ;;
esac
