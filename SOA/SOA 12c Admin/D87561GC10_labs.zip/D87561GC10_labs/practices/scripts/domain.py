if len(sys.argv) == 0:
  print "Usage: wlst domain.py [start|stop]"
  exit()
else:
  if sys.argv[1] != "start" and sys.argv[1] != "stop":
    print "Usage: wlst domain.py [start|stop]"
    exit()
  
domain_name="edg_domain"
try:
  domain_path = os.environ["ASERVER"]
except:
  domain_path="/u02/oracle/config/domains/" + domain_name

#lhost=java.net.InetAddress.getLocalHost().getHostName()
admhost="adminvh.example.com"

luser='weblogic'
admuser=raw_input("Username ["+ luser +"]: ")
if not admuser:
  admuser=luser

admpsw="".join(System.console().readPassword("%s",["Password: "]))
if not admpsw:
   print "Error: Please enter the WebLogic administrator password."
   exit()

#print "Domain: " + domain_path
#print "Host: " + admhost
#print "User: " + admuser

bootpfile=domain_path+"/servers/AdminServer/security/boot.properties"
bootpexists=os.path.exists(bootpfile)
if not bootpexists:
  print "Error: "+ bootpfile +" does not exist yet. Please create the file."
  exit()

try:
  print 'Connecting to Node Manager on '+admhost
  redirect('/dev/null','false')
  nmConnect(admuser, admpsw, admhost, 5556, domain_name, domain_path, 'ssl')
  stopRedirect()

  if sys.argv[1] == "start":
     nmStart('AdminServer')
     print "AdminServer started."
     print 'Connecting to AdminServer...'
     connect(admuser, admpsw, 't3://'+admhost+':7001')
     print 'Starting the soa_cluster1 Cluster...'
     start('soa_cluster1', 'Cluster')
     lbrBean=getMBean('/Servers/lbr_server')
     if lbrBean!=None:
       print 'Starting the load balancer server %s...' % lbrBean.getName()
       start(lbrBean.getName(),lbrBean.getType())
     disconnect()
  elif sys.argv[1] == "stop":
     print 'Connecting to AdminServer...'
     connect(admuser, admpsw, 't3://'+admhost+':7001')
     print 'Shutting down the soa_cluster1 Cluster...'
     shutdown('soa_cluster1', 'Cluster', force="true", block="true")
     lbrBean=getMBean('/Servers/lbr_server')
     if lbrBean!=None:
       print 'Shutting down the load balancer server %s...' % lbrBean.getName()
       shutdown(lbrBean.getName(),lbrBean.getType(), force="true", block="true")
     disconnect()
     print 'Stopping the AdminServer...'
     nmKill('AdminServer')
     print "AdminServer killed or stopped."
  else:
     print "Error: '" + sys.arv[1] + "' is an invalid command line parameter."

  nmDisconnect()
except:
  print "ERROR: Check error messages for cause."

exit()
