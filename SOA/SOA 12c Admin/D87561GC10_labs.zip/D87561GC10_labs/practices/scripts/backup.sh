#!/bin/bash

function backupDb() {
  if [ -z $ORACLE_BASE ]; then 
    echo "Warning: \$ORACLE_BASE environment variable not set. Run on host where database is configured."
    exit 1
  fi
  echo "Start database backup with tag ${TAG^^}..."
  sqlplus -s "/ as sysdba" <<-END
  PROMPT Shutting down database...
  SHUTDOWN IMMEDIATE;
  EXIT
END
  BACKUP_FILE=${BACKUP_DIR}/db_${TAG}.tar
  tar c${V}pf ${BACKUP_FILE} ${ORACLE_BASE}/oradata/${ORACLE_SID}/* \
          ${ORACLE_BASE}/fast_recovery_area/${ORACLE_SID}/*
  sqlplus -s "/ as sysdba" <<-END
  PROMPT Starting up database...
  STARTUP;
  EXIT
END
  
  echo "End database backup."
}

function backupAdminDomain() {
  echo "Start AdminServer Domain backup with id ${TAG}..."
  BACKUP_FILE=${BACKUP_DIR}/admindomain_${TAG}.tar 
  echo "Creating backup file ${BACKUP_FILE} ..."
  tar c${V}pf ${BACKUP_FILE} ${ASERVER}
  echo "End AdminServer Domain backup."
}

function backupDeployPlans () {
  echo "Start Deployment Plans backup with id ${TAG}..."
  BACKUP_FILE=${BACKUP_DIR}/deployplans_${TAG}.tar 
  echo "Creating backup file ${BACKUP_FILE} ..."
  tar c${V}pf ${BACKUP_FILE} ${DEPLOY_PLAN_HOME}
  echo "End Deployment Plans backup."
}
  
function backupAdminApps() {
  echo "Start AdminServer Applications backup with id ${TAG}..."
  BACKUP_FILE=${BACKUP_DIR}/adminapps_${TAG}.tar 
  echo "Creating backup file ${BACKUP_FILE} ..."
  tar c${V}pf ${BACKUP_FILE} ${APPHOME}
  echo "End AdminServer Applications backup."
}

function backupDeployPlans () {
  echo "Start Deployment Plans backup with id ${TAG}..."
  BACKUP_FILE=${BACKUP_DIR}/deployplans_${TAG}.tar 
  echo "Creating backup file ${BACKUP_FILE} ..."
  tar c${V}pf ${BACKUP_FILE} ${DEPLOY_PLAN_HOME}
  echo "End Deployment Plans backup."
}

function backupManagedConfig() {
  HOST=$(hostname -s)
  echo "Start Managed Server backup on host ${HOST} with id ${TAG}..."
  BACKUP_FILE=${BACKUP_DIR}/managedconfig_${TAG}_${HOST}.tar
  echo "Creating backup file ${BACKUP_FILE} ..."
  tar c${V}pf ${BACKUP_FILE} ${MSERVER}
  echo "End Managed Server backup."
}

function backupOUD() {
  OUD_HOME=/u02/oracle/product/fmw/asinst_1/OUD
  BACKUPDIR=${BACKUP_DIR}
  echo "Backing up the OUD directories..."
  $OUD_HOME/bin/backup --backUpAll --compress --backupDirectory ${BACKUPDIR}/oud --backupID ${TAG}
  cd ${OUD_HOME}
  echo "Backing up the OUD config folder..."
  tar cp${V}f ${BACKUPDIR}/oud/config_${TAG}.tar config/
  echo "Backing up the OUD logs folder..."
  tar cp${V}f ${BACKUPDIR}/oud/logs_${TAG}.tar logs/
  cd ${BACKUPDIR}
  echo "Creating backup archive..."
  tar cp${V}f ${BACKUPDIR}/oud_${TAG}.tar oud/
  rm -rf ${BACKUPDIR}/oud
  echo "Backup complete."
}

# Use parameter $2 as a tag and default to day and time in yymimdd_HHMMSS format
TAG=${2:-$(date +%y%m%d_%H%M%S)}
V=${VERIFY}

BACKUP_DIR=/u02/backup
ASERVER=${ASERVER:-/u02/oracle/config/domains/edg_domain}
APPHOME=${APPHOME:-/u02/oracle/config/applications/edg_domain}
MSERVER=${MSERVER:-/u01/oracle/config/domains/edg_domain}
DEPLOY_PLAN_HOME=/u02/oracle/config/dp

case "$1" in
db)
  backupDb ;;
admin)
  backupAdminDomain ;;
apps)
  backupAdminApps ;;
dplan)
  backupDeployPlans ;;
managed)
  backupManagedConfig ;;
ldap)
  backupOUD ;;
*)
  echo "Usage: $0 {admin|apps|db|dplan|ldap|managed} [tag/id]"
  exit 1
  ;;
esac
