#!/bin/bash

while getopts "v" opt; do
  case $opt in
    v)
      VIEWMDS=true;;
    \?)
      echo "Invalid option: -$OPTARG" >&2 ;;
  esac
done
shift $((OPTIND-1))

WLST=/u01/oracle/product/fmw/oracle_common/common/bin/wlst.sh
EARFILE=$1
if [ -z ${EARFILE} ]; then
  echo "Usage: $0 [/path/|path/]filename.ear"
  exit 1
else
  if [ -f ${EARFILE} ]; then
    if [ -z ${VIEWMDS} ]; then
      ${WLST} /practices/scripts/configmds.py ${EARFILE}
    else
      jar xf ${EARFILE} adf/META-INF/adf-config.xml
      sed -rn -e '/metadata-store-usages/,/\/metadata-store-usages/ p' adf/META-INF/adf-config.xml
      rm -rf adf/
    fi
  else
    echo "File '${EARFILE}' not found."
    exit 1
  fi
fi
