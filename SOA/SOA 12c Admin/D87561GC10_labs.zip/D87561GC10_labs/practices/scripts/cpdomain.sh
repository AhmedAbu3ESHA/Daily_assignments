#!/bin/bash
MW_HOME=${MW_HOME:-/u01/oracle/product/fmw}
ASERVER=${ASERVER:-/u02/oracle/config/domains/edg_domain}
MSERVER=${MSERVER:-/u01/oracle/config/domains/edg_domain}
APPHOME=${APPHOME:-/u02/oracle/config/applications/edg_domain}
LOGDIR=/practices/log

TEMPL_FILE=${2:-/practices/practice03/edgdomain_template.jar}
TEMPL_NAME=${TEMPL_FILE%.*}

# If the file name does not have a path prefix then add the current working directory
if [[ "${TEMPL_FILE}" == "${TEMPL_FILE%/*.*}" ]]; then
  TEMPL_FILE=${PWD}/${TEMPL_FILE}
fi

cd $MW_HOME/oracle_common/common/bin
case "$1" in
pack)
  echo "Packing domain in template file ${TEMPL_FILE}..."
  ./pack.sh -managed=true -domain=${ASERVER} -template=${TEMPL_FILE} -template_name=${TEMPL_NAME}
  ;;
unpack)
  echo "Unpacking domain from template file ${TEMPL_FILE}..."
  ./unpack.sh -domain=${MSERVER} -overwrite_domain=true -template=${TEMPL_FILE} -log_priority=DEBUG \
              -log=${LOGDIR}/${1}_${TEMPL_NAME}.log -app_dir=${APPHOME}
  ;;
*)
  echo "Usage: $0 {pack|unpack} [[path/]template_file_name]"
  exit 3
  ;;
esac


