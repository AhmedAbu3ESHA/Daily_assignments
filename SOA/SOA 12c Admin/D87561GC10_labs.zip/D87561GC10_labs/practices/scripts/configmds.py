if len(sys.argv) == 0:
  print "Usage: wlst configmds.py [/path/|path/]filename.ear"
  exit()

print "Updating adf-config.xml in file: " + sys.argv[1]
print "Setting repository=mds-soa, partition=soa-infra, type=DB, jndipath=jdbc/mds/MDS_LocalTxDataSource,..."
archive = getMDSArchiveConfig(fromLocation=sys.argv[1])
archive.setAppSharedMetadataRepository(namespace='/soa/shared',
        repository='mds-soa', partition='soa-infra', type='DB',
        jndi='jdbc/mds/MDS_LocalTxDataSource')
print "Saving changes to file: " + sys.argv[1]
archive.save(toLocation=sys.argv[1])
print "File: " + sys.argv[1] + " updated."
