import wlstModule
from com.bea.wli.sb.management.configuration import SessionManagementMBean
from com.bea.wli.sb.management.configuration import ALSBConfigurationMBean
from com.bea.wli.config import Ref

try:
    # Connect to the SB domain
    connect(url='t3://localhost:7001')
    domainRuntime()
    
    # Add the code to obtain session management mbean to create a session.
    sessionMBean = findService(SessionManagementMBean.NAME, SessionManagementMBean.TYPE)

    # Add the code to create a new session
    print '...Creating a new session...'
    sessionMBean.createSession("ImportSession")
    
    # Add the code to obtain the ALSBConfigurationMBean instance that operates on the session that has just been created.
    alsbSession = findService(ALSBConfigurationMBean.NAME + "." +
 	"ImportSession",ALSBConfigurationMBean.TYPE)
    
    # Read the JAR file containing the SB projects
    print 'Read binary file...' 
    file = open("/home/oracle/labs_SA/Practice_05/wlst/import/sample_sbconfig.jar", 'rb')
    bytes = file.read()   
    
    # Add the code to import configuration into the session. First add the code to upload the JAR file, which will stage it temporarily. 
    alsbSession.uploadJarFile(bytes)

    # Add the code to import the JAR file into the SB domain
    alsbSession.importUploaded(None)
    
    # Add the code to activate the changes performed in the session
    print 'Activating the session...'
    sessionMBean.activateSession("ImportSession", "Imported the project.")

    # Disconnect from the server
    disconnect()

except:
    print "Unexpected error: ", sys.exc_info()[0]
    dumpStack()
    raise

