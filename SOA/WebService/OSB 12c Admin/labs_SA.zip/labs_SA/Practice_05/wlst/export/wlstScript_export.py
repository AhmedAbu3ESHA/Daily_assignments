import wlstModule
from com.bea.wli.sb.management.configuration import SessionManagementMBean
from com.bea.wli.sb.management.configuration import ALSBConfigurationMBean
from com.bea.wli.config import Ref
from java.util import Collections
from java.io import FileOutputStream

try:
    print 'Connecting to server...'
    connect(url='t3://localhost:7001')
    domainRuntime()
    
    # Add the code to obtain the Mbean for peforming read only operations.
          
    # Add the code to create a new Ref object that identifies the SB project
    
    # Add the code to assign the Ref object to a new Java Collection
    
    # Add the code to export the SB project using the 'export' method of the ALSBConfigurationMBean

    print 'Writing to a JAR file......'

    myfile = File("/home/oracle/labs_SA/Practice_05/wlst/export/Practice_05_sbconfig.jar")
    out = FileOutputStream(myfile)
    out.write(theBytes)
    out.close() 
    
    # Add the code to disconnect from the server
    
except:
    print "Unexpected error: ", sys.exc_info()[0]
    dumpStack()
    raise
