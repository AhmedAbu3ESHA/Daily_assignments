# !/bin/bash
# Developed by Bijoy Choudhury and edited by Mary Peek 12/5/11
# Modified by Cindy Church 3/13/15
# This shell script set the specific WLS Env variables, CLASSPATH, PATH, etc..
# to deploy (import) a project in a SB domain by using WLST commands...

# Set the Environment Variables
source /u01/app/oracle/fmw_admin/12.1.3.0/user_projects/domains/osb_domain/bin/setDomainEnv.sh

# Execute the WLST script..
cd /home/oracle/labs_SA/Practice_05/wlst/export/
/u01/app/oracle/fmw_admin/12.1.3.0/osb/common/bin/wlst.sh wlstScript_export.py 
