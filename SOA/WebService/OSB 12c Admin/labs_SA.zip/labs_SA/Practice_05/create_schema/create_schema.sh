# !/bin/bash
# Developed by Mary Peek 
# Modified by Cindy Church May 2015
# This shell script creates a schema using RCU in the silent mode and a password file. It is not best # practice to include the passwordfile.txt, but we are using it in this course for expediting the   
# creation of a schema that is required for domain creation. 


# Navigate to folder that contains RCU script and create schemas with PROD1 prefix using the 
# silent mode

cd /u01/app/oracle/fmw_admin/12.1.3.0/oracle_common/bin
export ORACLEDB=localhost:1521:ORCL
./rcu -silent -createRepository -connectString $ORACLEDB -dbUser sys -dbRole sysdba -schemaPrefix PROD1 -component SOAINFRA -component MDS -component IAU -component IAU_APPEND -component IAU_VIEWER -component OPSS -component WLS -component STB -component UCSUMS -f < /home/oracle/labs_SA/Practice_05/create_schema/passwordfile.txt
