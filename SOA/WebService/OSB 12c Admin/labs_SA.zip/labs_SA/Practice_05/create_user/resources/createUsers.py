
url = 'localhost:7001'
username = 'weblogic'
password = 'welcome1'

print 'Adding users to DefaultAuthenticator.'
connect(username, password, url)

# Check if user already exists
cd('/')
authProvider = cmo.getSecurityConfiguration().getDefaultRealm().lookupAuthenticationProvider("DefaultAuthenticator")
if authProvider.userExists('jdoe'):
	print 'User jdoe already exists'
	exit()
else:
	# Create users
	print 'Creating new user: jdoe'
	authProvider.createUser('jdoe','welcome1','a sample service bus administrator')
	authProvider.addMemberToGroup('Administrators','jdoe')

print 'Users created successfully.'
exit()
