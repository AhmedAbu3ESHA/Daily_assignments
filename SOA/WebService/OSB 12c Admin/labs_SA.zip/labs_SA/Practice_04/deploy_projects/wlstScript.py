# Script developed by Bijoy Choudhury
# Updated by Cindy Church May 2015
# The script will import an SB project.. 
# ..defined in the sbconfig.jar file within a SB Domain

import wlstModule
from com.bea.wli.sb.management.configuration import SessionManagementMBean
from com.bea.wli.sb.management.configuration import ALSBConfigurationMBean
from com.bea.wli.config import Ref

try:
    # Connect to the SB domain
    connect("weblogic", "welcome1", "t3://localhost:7001")
    domainRuntime()
    
    # Obtain session management mbean to create a session.
    sessionMBean = findService(SessionManagementMBean.NAME,SessionManagementMBean.TYPE)
    
    # Create a session
    print 'Creating a session...'
    sessionMBean.createSession("ImportSession")
    
    # Obtain the ALSBConfigurationMBean instance that operates..
    # ..on the session that has just been created.
    alsbSession = findService(ALSBConfigurationMBean.NAME + "." + "ImportSession",ALSBConfigurationMBean.TYPE)
    
    # Read the JAR file containing the SB projects
    print 'Read binary file...' 
    file = open("./sbconfig.jar", 'rb')
    bytes = file.read()   
    
    # Import the Project within the SB domain
    print 'Importing the project...'
    alsbSession.uploadJarFile(bytes)
    alsbSession.importUploaded(None)
    
    # Activate changes performed in the session
    print 'Activating the session...'
    sessionMBean.activateSession("ImportSession", "Imported the project.")

    # Disconnect from the second domain
    disconnect()

except:
    print "Unexpected error: ", sys.exc_info()[0]
    dumpStack()
    raise
