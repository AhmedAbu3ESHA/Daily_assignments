# !/bin/bash
# Developed by Iris Li 
# Modified by Cindy Church 3/9/15
# This shell script set the specific WLS Env variables, CLASSPATH, PATH, etc..
# to deploy (import) a project in an OSB domain by using WLST commands...

# Set the Environment Variables
source /u01/app/oracle/fmw_admin/12.1.3.0/user_projects/domains/osb_domain/bin/setDomainEnv.sh

# Execute the WLST script..
cd /home/oracle/labs_SA/Practice_04/deploy_projects
/u01/app/oracle/fmw_admin/12.1.3.0/osb/common/bin/wlst.sh wlstScript.py
