# !/bin/bash
# Developed by Mary Peek 
# Modified by Cindy Church May 2015
# This shell script set 

# Set the Environment Variables

# Navigate to folder that contains RCU script and create schemas with PROD prefix using the 
# silent mode

cd /u01/app/oracle/fmw_admin/12.1.3.0/oracle_common/bin
export ORACLEDB=localhost:1521:ORCL
./rcu -silent -createRepository -connectString $ORACLEDB -dbUser sys -dbRole sysdba -schemaPrefix PROD -component SOAINFRA -component MDS -component IAU -component IAU_APPEND -component IAU_VIEWER -component OPSS -component UMS -component WLS -component STB -component UCSUMS -component ESS -f < /home/oracle/labs_SA/Practice_03/Solutions/passwordfile.txt
