#####################################################################################
# This WLST script deploys the six service applications required for the SA practices
# to the Administration Server.
#
# Written by Mary Peek 12/1/11
# Modified by Cindy Church 3/5/15
# Oracle Service Bus 12c: System Administration course
#####################################################################################

url = 'localhost:7001'
username = 'weblogic'
password = 'welcome1'
target = 'AdminServer'

# Connect to administration server
connect(username, password, url)

# Deploy the applications

print 'Deploying CreditCardValidationService_WS'
progress = deploy(appName='CreditCardValidationService_WS',path='/home/oracle/stage/Svc_Apps/CreditCardValidationService_WS.war',targets=target)
# Wait for deploy to complete
while progress.isRunning():
	pass

print 'Deploying OrderServices'
progress = deploy(appName='OrderServices',path='/home/oracle/stage/Svc_Apps/OrderServices.war',targets=target)
# Wait for deploy to complete
while progress.isRunning():
	pass

print 'Deploying OrderStatusApplication'
progress = deploy(appName='OrderStatusApplication',path='/home/oracle/stage/Svc_Apps/OrderStatusApplication.war',targets=target)
# Wait for deploy to complete
while progress.isRunning():
	pass

print 'Deploying PaymentServices'
progress = deploy(appName='PaymentServices',path='/home/oracle/stage/Svc_Apps/PaymentServices.war',targets=target)
# Wait for deploy to complete
while progress.isRunning():
	pass

print 'Deploying ServiceA_App-Service_A-context-root'
progress = deploy(appName='ServiceA_App-Service_A-context-root',path='/home/oracle/stage/Svc_Apps/ServiceA_App-Service_A-context-root.war',targets=target)
# Wait for deploy to complete
while progress.isRunning():
	pass

print 'Deploying ServiceA_App-Service_B-context-root'
progress = deploy(appName='ServiceA_App-Service_B-context-root',path='/home/oracle/stage/Svc_Apps/ServiceA_App-Service_B-context-root.war',targets=target)
# Wait for deploy to complete
while progress.isRunning():
	pass

print 'Deploying ServiceA_App-Service_C-context-root'
progress = deploy(appName='ServiceA_App-Service_C-context-root',path='/home/oracle/stage/Svc_Apps/ServiceA_App-Service_C-context-root.war',targets=target)
# Wait for deploy to complete
while progress.isRunning():
	pass

print 'Deploying ShippingServices'
progress = deploy(appName='ShippingServices',path='/home/oracle/stage/Svc_Apps/ShippingServices.war',targets=target)
# Wait for deploy to complete
while progress.isRunning():
	pass

print 'Applications deployed.'

exit()
