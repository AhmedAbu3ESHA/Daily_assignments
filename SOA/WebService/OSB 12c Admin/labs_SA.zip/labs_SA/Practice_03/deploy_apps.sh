#!/bin/bash

##################################################################################
# This script deploys the six service applications required for the SA practices.
# It first sources setWLSEnv.sh to set java.exe in the path and weblogic.jar in 
# the CLASSPATH.
# Then it runs the deploy_svc_apps.py WLST script to actually deploy the
# applications.
#
# Written by Mary Peek 12/1/11
# Modified by Cindy Church 3/4/15
# Oracle Service Bus 12c: System Administration course
##################################################################################

export WL_HOME=/u01/app/oracle/fmw_admin/12.1.3.0/wlserver

source $WL_HOME/server/bin/setWLSEnv.sh

#Deploy applications
echo "***** Deploying service applications *****"
java weblogic.WLST deploy_svc_apps.py

echo -e "\n***** Deployment of service applications complete! *****\n"
