package com.ecommerce.Entites;

public class ExchangeRate {
    private double rate;

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }
}
