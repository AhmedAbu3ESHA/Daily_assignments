import java.sql.*;
import java.util.Scanner;

public class Main2 {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("enter salary");
        int salary=s.nextInt();
        //connection

        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hr", "root", "root123");
             PreparedStatement st =
                     con.prepareStatement("select * from employees where salary>? and last_name =?");){

            st.setInt(1,salary);
            st.setString(2,"nemr");
            try(ResultSet resultSet = st.executeQuery();) {
                while (resultSet.next()){
                    System.out.println(resultSet.getString("first_name")
                            +" "+resultSet.getInt("salary"));
                }
            }catch (Exception e){

            }

        } catch (SQLException e) {

        }


    }
}
