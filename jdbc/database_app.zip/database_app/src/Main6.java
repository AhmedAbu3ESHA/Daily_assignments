import java.sql.*;
import java.time.LocalDate;

public class Main6 {
    public static void main(String[] args) {

        try(Connection con = DriverManager
                .getConnection("jdbc:mysql://localhost/hr", "root", "root123");
            CallableStatement st=con.prepareCall("{call addDepartment(?,?,?)}");
        ) {
            st.setString(1,"test1");
            st.setObject(2, LocalDate.now());

            st.registerOutParameter(3,java.sql.Types.INTEGER);
            boolean a=st.execute();
            System.out.println(st.getInt(3));
            if (a) {
//                ResultSet rs=st.getResultSet();
//                if (rs.next()){
//                    System.out.println(rs.getInt(1));
//                }
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }
}
