import java.sql.*;

public class Main7 {
    public static void main(String[] args) {
        try {
            Connection con = DriverManager
                    .getConnection("jdbc:mysql://localhost/hr", "root", "root123");
            Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            st.setFetchSize(10);
            ResultSet resultSet = st.executeQuery("select * from departments");
            resultSet.last();
            resultSet.getRow();
//            resultSet.absolute(5)



        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
