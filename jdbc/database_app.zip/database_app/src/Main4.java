import java.sql.*;
import java.time.LocalDate;
import java.util.Arrays;

public class Main4 {
    public static void main(String[] args) {
        try (Connection con = DriverManager
                .getConnection("jdbc:mysql://localhost/hr", "root", "root123");

             PreparedStatement st =
                     con.prepareStatement("select * from empdept");){

            ResultSet rs=st.executeQuery();
            while (rs.next()){
                System.out.println(rs.getString("first_name")+
                        rs.getString("name"));
            }
//            st.setObject(1, LocalDate.now());
//            st.setString(1,"test1");
//            st.addBatch();
//            st.executeUpdate();

//            st.setString(1, "test2");
//            st.addBatch();
//            st.executeUpdate();

//            st.setString(1, "test3");
//            st.addBatch();

//            int[] rows = st.executeBatch();
//            System.out.println(Arrays.toString(rows));
//            st.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }
}
