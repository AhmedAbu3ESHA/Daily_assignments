import java.sql.*;

public class Main3 {
    public static void main(String[] args) {
        Connection con=null;
        try  {
            con = DriverManager
                    .getConnection("jdbc:mysql://localhost/hr", "root", "root123");
            PreparedStatement st =
                    con.prepareStatement("insert into departments(name) values (?)"
                            ,Statement.RETURN_GENERATED_KEYS);

            con.setAutoCommit(false);

            st.setString(1,"fun");

            int rows = st.executeUpdate();

            ResultSet resultSet = st.getGeneratedKeys();
            if(resultSet.next()){
                int departmentID = resultSet.getInt(1);
                System.out.println(departmentID);
                //save employee
                PreparedStatement empSt = con.prepareStatement("insert into employees1 (first_name,last_name,salary,department_id) values (?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
                empSt.setString(1,"moharram");
                empSt.setString(2,"othman");
                empSt.setInt(3,3000);
                empSt.setInt(4,departmentID);
                int empRows = empSt.executeUpdate();
                System.out.println(empRows);

                ResultSet empRs = empSt.getGeneratedKeys();
                if (empRs.next()){
                    System.out.println(empRs.getInt(1));
                    con.commit();
                }
            }else{
                con.rollback();
            }

            con.setAutoCommit(true);

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            try {
                con.rollback();
                con.close();
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        }
    }
}
