import java.sql.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//        jdbc:mysql://localhost/hr

        Scanner s=new Scanner(System.in);
        System.out.println("enter salary");
        int salary=s.nextInt();
        //connection

        try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hr", "root", "root123");
            Statement st = con.createStatement();
            ResultSet resultSet = st
                    .executeQuery("select first_name as name from employees where salary>"+salary+" and city= ");
        ) {

            while (resultSet.next()){
                System.out.println(resultSet.getString("name"));
            }

        } catch (SQLException e) {

        }


    }
}