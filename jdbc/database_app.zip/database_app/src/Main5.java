import java.sql.*;
import java.time.LocalDate;

public class Main5 {
    public static void main(String[] args) {
        try {

//            views
//            stored procedure
//            setfetchsize
//            updatable resultset
            // connection pool

            Connection con=ConnectionUtils.getConnection();
//            Connection con = DriverManager
//                    .getConnection("jdbc:mysql://localhost/hr", "root", "root123");

            Statement st = con
                    .createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                            ResultSet.CONCUR_UPDATABLE);

            st.setFetchSize(1);

            ResultSet resultSet = st.executeQuery("select * from departments limit 1");
            resultSet.next();
            System.out.println(resultSet.getString(2));
            resultSet.updateString(2,"sales2");
            resultSet.updateRow();
            System.out.println(resultSet.getString(2));

            while (resultSet.next()){
                System.out.println(resultSet.getString("name"));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
